import React, { useState } from "react";
import '../day1/style.css';
 
const Exe1Fun = () => {
    const [ID, setID] = useState('');
    const [Name, setName] = useState('');
    const [Salary, setSalary] = useState('');
    const [Department, setDepartment] = useState('');
    const [submittedData, setSubmittedData] = useState([
        { ID: 1, Name: "rahul", Salary: 20000, Department: "cs" },
        { ID: 2, Name: "chandru", Salary: 30000, Department: "it" }
    ]);
    const [editing, setEditing] = useState(false);
    const [currId, setCurrId] = useState('');
 
    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === "ID") setID(value);
        else if (name === "Name") setName(value);
        else if (name === "Salary") setSalary(value);
        else if (name === "Department") setDepartment(value);
    };
 
    const formSubmit = (e) => {
        e.preventDefault();
        if (editing) {
            const updatedData = submittedData.map((emp) =>
                emp.ID === currId ? { ID, Name, Salary, Department } : emp
            );
            setSubmittedData(updatedData);
            setEditing(false);
            setCurrId('');
        } else {
            setSubmittedData([...submittedData, { ID, Name, Salary, Department }]);
        }
        setID('');
        setName('');
        setSalary('');
        setDepartment('');
    };
 
    const handleUpdate = (id) => {
        const empData = submittedData.find((row) => row.ID === id);
        setID(empData.ID);
        setName(empData.Name);
        setSalary(empData.Salary);
        setDepartment(empData.Department);
        setEditing(true);
        setCurrId(id);
    };
 
    const handleDelete = (id) => {
        setSubmittedData(submittedData.filter((row) => row.ID !== id));
    };
 
    return (
        <div className="parent">
            <div className="right ">
                <form onSubmit={formSubmit}>
                    <fieldset className="border p-4">
                        <legend className="ht">Form</legend>
                        <div className="form">
                            <label className="form-label int">ID
                                <input className="form-control" type="number" name="ID" value={ID} onChange={handleChange} placeholder="Enter ID" required /><br />
                            </label>
                            <label className="form-label int">Name
                                <input className="form-control" type="text" name="Name" value={Name} onChange={handleChange} placeholder="Enter Name" required /><br />
                            </label>
                            <label className="form-label int">Salary
                                <input className="form-control" type="number" name="Salary" value={Salary} onChange={handleChange} placeholder="Enter Salary" required /><br />
                            </label>
                            <label className="form-label int">Department
                                <input className="form-control" type="text" name="Department" value={Department} onChange={handleChange} placeholder="Enter Department" required /><br />
                            </label>
                            <button className="btn btn-primary button" type="submit">Submit All</button>
                        </div>
                    </fieldset>
                </form>
                <table className="table table table-hover table-bordered table-striped">
                    <thead className="table-dark">
                        <tr className="tr">
                            <th>ID</th>
                            <th>Name</th>
                            <th>Salary</th>
                            <th>Department</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {submittedData.map((row) => (
                            <tr className="tr" key={row.ID}>
                                <td>{row.ID}</td>
                                <td>{row.Name}</td>
                                <td>{row.Salary}</td>
                                <td>{row.Department}</td>
                                <td>
                                    <button className="btn btn-secondary int" onClick={() => handleUpdate(row.ID)}>Update</button>
                                    <button className="btn btn-danger" onClick={() => handleDelete(row.ID)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
 
export default Exe1Fun;