import React, { useState } from "react";
import '../day1/style.css';
 
const Exe2Fun = () => {
    const [formState, setFormState] = useState({
        Id: '',
        Name: '',
        Cost: '',
        radioOption: '',
        SelectedValue: '',
        PrintChecked: [],
        submittedData: []
    });
 
    const handleCheckboxChange = (event) => {
        const { value, checked } = event.target;
        setFormState((prevState) => {
            if (checked) {
                return {
                    ...prevState,
                    PrintChecked: [...prevState.PrintChecked, value, ',']
                };
            } else {
                return {
                    ...prevState,
                    PrintChecked: prevState.PrintChecked.filter(item => item !== value)
                };
            }
        });
    };
 
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormState(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
 
    const formSubmit = (e) => {
        e.preventDefault();
        const { Id, Name, Cost, radioOption, SelectedValue, PrintChecked } = formState;
        setFormState(prevState => ({
            ...prevState,
            submittedData: [...prevState.submittedData, { Id, Name, Cost, radioOption, SelectedValue, PrintChecked }],
            Id: '',
            Name: '',
            Cost: '',
            radioOption: '',
            SelectedValue: '',
            PrintChecked: []
        }));
    };
 
    const { Id, Name, Cost, submittedData, SelectedValue } = formState;
 
    return (
        <div className="first">
            <div>
                <form onSubmit={formSubmit}>
                    <div className="container">
                        <legend style={{ color: "green" }} className="ht">Solution 3</legend>
                        <div className="cg">
                            <tr>
                                <td>
                                    <label className="form-label int item">Product ID</label>
                                </td>
                                <td>
                                    <input className="form-control bh" type="number" name="Id" value={Id} onChange={handleChange} /><br />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="form-label int item">Product Name</label>
                                </td>
                                <td>
                                    <input className="form-control bh" type="text" name="Name" value={Name} onChange={handleChange} /><br />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="form-label int item">Product Cost</label>
                                </td>
                                <td>
                                    <input className="form-control bh" type="number" name="Cost" value={Cost} onChange={handleChange} /><br />
                                </td>
                            </tr>
                        </div>
                        <div className="gb">
                            <tr>
                                <td>
                                    <label className="form-label int item">Product Online</label>
                                </td>
                                <td>
                                    <label className="form-label int">
                                        <input type="radio" name="radioOption" value="Yes" onChange={handleChange} />
                                        Yes</label>
                                    <label className="form-label int">
                                        <input type="radio" name="radioOption" value="No" onChange={handleChange} />
                                        No</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="form-label int item">Product Category</label>
                                </td>
                                <td>
                                    <select name="SelectedValue" value={SelectedValue} onChange={handleChange}>
                                        <option value="">Select</option>
                                        <option value="Grocery">Grocery</option>
                                        <option value="Mobile">Mobile</option>
                                        <option value="Electronics">Electronics</option>
                                        <option value="Cloths">Cloths</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label className="form-label int item">Available in store</label>
                                </td>
                                <td>
                                    <label className="form-label int">
                                        <input type="checkbox" name="BigBazar" value="BigBazar" onChange={handleCheckboxChange} />
                                        BigBazar</label>
                                    <label className="form-label int">
                                        <input type="checkbox" name="Dmart" value="Dmart" onChange={handleCheckboxChange} />
                                        Dmart</label>
                                    <label className="form-label int">
                                        <input type="checkbox" name="Reliance" value="Reliance" onChange={handleCheckboxChange} />
                                        Reliance</label>
                                    <label className="form-label int">
                                        <input type="checkbox" name="MegaStore" value="MegaStore" onChange={handleCheckboxChange} />
                                        MegaStore</label>
                                </td>
                            </tr>
                        </div>
                        <div>
                            <tr>
                                <td>
                                    <br></br>
                                    <br></br>
                                    <button type="submit" className="btn btn-outline-success btn-sm int">Submit All</button>
                                </td>
                            </tr>
                        </div>
                    </div>
                </form>
                <table className="table table-hover table-bordered table-striped">
                    <thead className="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Cost</th>
                            <th>Online</th>
                            <th>Category</th>
                            <th>Store</th>
                        </tr>
                    </thead>
                    <tbody>
                        {submittedData.map((row, index) => {
                            return (
                                <tr key={index}>
                                    <td>{row.Id}</td>
                                    <td>{row.Name}</td>
                                    <td>{row.Cost}</td>
                                    <td>{row.radioOption}</td>
                                    <td>{row.SelectedValue}</td>
                                    <td>{row.PrintChecked}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
 
export default Exe2Fun;