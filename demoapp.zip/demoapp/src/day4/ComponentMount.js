import React from "react";

export default class ComponentMount extends React.Component{
    constructor(){
        console.log("From Constructor");
        super();
        this.state ={
            data:null
        }
    }

    componentWillMount(){
        console.log("Will Mount");
    }

    componentDidMount(){
        setTimeout(() => {
            const fetcheddata = "NEW Data placed here";
            this.setState({data: fetcheddata})
        },5000)
    }

    render(){
        return (
            <div>
                <h1 style={{textAlign:"center"}}>componentDidMount</h1>
                {this.state.data ? (<p>{this.state.data}</p>) : <p>Old Data</p>}
            </div>
        )
    }

}