import React from "react";

class Mine extends React.Component
{
    constructor(props){
        super(props)
        this.state={
            Id: '',
            Name: '',
            Cost: '',
            radioOption:'',
            Category: '',
            CheckedBox:{
                BigBazar:false,
                Dmart:false,
                Reliance:false,
                MegaStore:false
            },
            PrintChecked:[],
            submittedData:[],
            SelectedValue:''
        }
    };

    handleCheckboxChange = (event) => {
        const { value, checked } = event.target;
        this.setState(prevState => {
          if (checked) {
            this.setState({value:true});
            return {
                PrintChecked: [...prevState.PrintChecked, value]
            };
          } else {
            return {
                PrintChecked: prevState.PrintChecked.filter(item => item !== value)
            };
          }
        });
      }

    handlechange = (e) => {
        this.setState({[e.target.name]:e.target.value});
    }

    formsubmit = (e) => {
        e.preventDefault();
        const { Id, Name, Cost, radioOption, SelectedValue, PrintChecked } = this.state;
        this.setState((prevState) => ({
            submittedData: [...prevState.submittedData, { Id, Name, Cost, radioOption, SelectedValue,  PrintChecked}],
            Id: '',
            Name: '',
            Cost: '',
            radioOption:'',
            SelectedValue:'',
            PrintChecked:[]
        }));
    };

    
    render(){
        const { Id, Name, Cost, radioOption, PrintChecked, CheckedBox, submittedData, SelectedValue } = this.state;
        return (
        <div>
            <div>
                    <form onSubmit={this.formsubmit} >
                        <div class="mb-3 mt-3">
                        <fieldset>
                            <legend>Solution 3</legend>
                            <div>
                                <tr>
                                    <td>
                                        <label class="form-label">Product ID</label>
                                    </td>
                                    <td>
                                        <input class="form-control" type="number" name="Id"  value={Id}  onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Product Name</label>
                                    </td>
                                    <td>
                                        <input class="form-control" type="text" name="Name" value={Name} onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Product Cost</label>
                                    </td>
                                    <td>
                                        <input class="form-control" type="number" name="Cost" value={Cost} onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Product Online</label>
                                    </td>
                                    <td>
                                        <input type="radio" name="radioOption" value="Yes"  checked={radioOption === "Yes"} onChange={this.handlechange}></input>
                                        <label class="form-label">Yes</label>
                                        <input type="radio" name="radioOption" value="No"  checked={radioOption === "No"} onChange={this.handlechange}></input>
                                        <label class="form-label">No</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Product Category</label>
                                    </td>
                                    <td>
                                        <select name="SelectedValue" value={SelectedValue} onChange={this.handlechange}>
                                            <option value="">Select</option>
                                            <option value="Grocery">Grocery</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Electronics">Electronics</option> 
                                            <option value="Cloths">Cloths</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label">Available in store</label>
                                    </td>
                                    <td>
                                        <label class="form-label">
                                        <input type="checkbox" name="BigBazar" value={CheckedBox.BigBazar} checked={CheckedBox.BigBazar} onChange={this.handleCheckboxChange}  />
                                        BigBazar</label>
                                        <label class="form-label">
                                        <input type="checkbox" name="Dmart" value="Dmart" checked={CheckedBox.Dmart} onChange={this.handleCheckboxChange}  />
                                        Dmart</label>
                                        <label class="form-label">
                                        <input type="checkbox" name="Reliance" value="Reliance" checked={CheckedBox.Reliance} onChange={this.handleCheckboxChange} />
                                        Reliance</label>
                                        <label class="form-label">
                                        <input type="checkbox" name="MegaStore" value="MegaStore" checked={CheckedBox.MegaStore} onChange={this.handleCheckboxChange} />
                                        MegaStore</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <button type="submit" class="btn btn-outline-success btn-sm">Submit All</button>
                                    </td>
                                </tr>
                            </div>
                        </fieldset>
                        </div>
                    </form>
                     <table className="table table table-hover table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Cost</th>
                                <th>Online</th>
                                <th>Category</th>
                                <th>Store</th>
                            </tr>
                        </thead>
                        <tbody>
                            {submittedData.map((row,index) => { return (
                                <tr key={index}>
                                    <td>{row.Id}</td>
                                    <td>{row.Name}</td>
                                    <td>{row.Cost}</td>
                                    <td>{row.radioOption}</td>
                                    <td>{row.SelectedValue}</td>
                                    <td>{row.PrintChecked}</td>
                                </tr>
                            );})}
                        </tbody>
                    </table>
                </div>
        </div>
        ); } 
}
export default Mine;