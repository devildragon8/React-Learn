import React from "react";


export default class ComponentWillUnmount extends React.Component{
    constructor(){
        super()
        this.state={
            showChild : true
        }
    }

    handleDelete = () => {
        this.setState({showChild:false})
    }

    render(){
        return(
            <div>
                {this.state.showChild && <Child/>}
                <button type="button" onClick={this.handleDelete}>Delete</button>
            </div>
        );
    }


}

class Child extends React.Component{
    componentWillUnmount(){
        alert('about to unmount');
    }

    render(){
        return(
            <div>
                <p>I will be gone once Delete Clicked</p>
            </div>
        );
    }

}
