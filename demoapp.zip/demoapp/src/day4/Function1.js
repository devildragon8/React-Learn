import React from "react";
import './classComponent.css';
import Cmp2 from './cmp2.js';
import Emp from './emp.js';
import Form2 from './Form2.js';

class ClassComponent extends React.Component
{
    constructor(props){
        super(props)
        this.state={
            data:"",
            emps:[
            {id:1,name:'A',salary:1},
            {id:2,name:'B',salary:2},
            {id:3,name:'C',salary:3},
            {id:4,name:'D',salary:4}
            ],
            ID:'',
            Name:'',
            Salary:'',
            Department:'',
            submittedData:[
                {ID:1,Name:"rahul",Salary:20000,Department:"cs"},
            ],
            updateField:'',
            updateValue:''
        }
    };

    changeState = () => {
        this.setState({data:"From Cmp2"});
    }

    handlechange = (e) => {
        this.setState({[e.target.name]:e.target.value});
    }

    formsubmit = (e) => {
        e.preventDefault();
        const { ID, Name, Salary , Department } = this.state;
        this.setState((prevState) => ({
            submittedData: [...prevState.submittedData, { ID, Name, Salary , Department }],
            ID: '',
            Name: '',
            Salary: '',
            Department: '',
        }));
    };

    handleUpdate = (id) => {
        this.setState(prevState => ({
          tableData: prevState.submittedData.map(row => {
        if (row.id === id) {
              return { ...row, name: prevState.updateValue }; // Update the specific field
            }
            return row;
          }),
          updateValue: '' // Clear the input after updating
        }));
      }


    // handleDelete = (id) => {
    //     this.setState(prevState => ({
    //         submittedData: prevState.submittedData.filter(row => row.id !== id)
    //     }));
    //   }

    
    render(){
         return(
        <div className="parent">
            {/* <Cmp2 data1={this.state.data}></Cmp2>
            <p>ClassComponent</p>
            <button onClick={this.changeState} type="button">Click</button> */}
            {/* <div class="left">
                <div class="">
                    <table style={{width: "200px", color: "Green", height: "200px" }} border="1">
                        <tbody>
                        { this.state.emps.map((emp) => { return (
                            <Emp key={emp.id}>{emp.name}</Emp>
                        ); }) }
                        </tbody>
                    </table>
                </div>
            </div> */}
        
            <div className="right ">
    
                    <form onSubmit={this.formsubmit} >
                        <fieldset>
                            <legend>Form</legend>
                            <div className="form">
                            <label>ID</label>
                            <input type="number" name="ID" value={this.state.ID} onChange={this.handlechange} placeholder="Enter ID" required /><br/>
                        
                            <label>Name</label>
                            <input type="text" name="Name" value={this.state.Name} onChange={this.handlechange} placeholder="Enter Name" required /><br/>
                        
                            <label>Salary</label>
                            <input type="number" name="Salary" value={this.state.Salary} onChange={this.handlechange} placeholder="Enter Salary" required />
                            <br/>
                            <label>Department</label>
                            <input type="text" name="Department" value={this.state.Department} onChange={this.handlechange} placeholder="Enter Department" required /><br/>
                            
                        <button type="submit">Submit All</button>
                        </div>
                        </fieldset>
                      
                    </form>
                    {/* { this.state.submittedData.map((data) => { return (
                            <Form2 Id={data.ID} name={data.Name} salary={data.Salary} department={data.Department}/>
                        ); }) } */}
                     <table  border="1"  className="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Salary</th>
                                <th>Department</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.submittedData.map((row,index) => { return (
                                <tr key={index}>
                                    <td>{row.ID}</td>
                                    <td>{row.Name}</td>
                                    <td>{row.Salary}</td>
                                    <td>{row.Department}</td>
                                    <td>
                                        <button onClick={this.handleUpdate(row.ID)}>Update</button>
                                        {/* <button onClick={this.handleDelete(row.ID)}>Delete</button> */}
                                    </td>
                                </tr>
                            );})}
                        </tbody>
                    </table>
                </div>
        </div>
        ); } 
}
export default ClassComponent;