import React, {useState} from 'react';



export default function Name(){
    const[name, setName] = useState({firstname:"",lastname:""});
    return(
        <div>
            <form>
            <input type="text" value={name.firstname} onChange={e => setName({...name, firstname:e.target.value})}/>
            <input type="text" value={name.lastname} onChange={e => setName({...name, lastname:e.target.value})}/>
            <h3>FirstName - {name.firstname}</h3>
            <h3>LastName - {name.lastname}</h3>
            <p>{JSON.stringify(name)}</p>
            </form>
        </div>
    );

}