import React from "react";

export default class ShouldComponentUpdate extends React.Component{
    constructor(props){
        super();
        this.state ={
            count:0
        }
    }

    shouldComponentUpdate(nextProps, nextState){
        console.log("props:"+nextProps);
        if(nextState.count % 2 === 0){
            return true; // re- render
        }
        return false;// no re- render
    }

    componentDidUpdate(prevProps,prevState){
        console.log("component updated");
        console.log("old count",prevState);
        console.log("new count",this.state);
    }

    increment = () => {
        this.setState ((prevState) => ({count: prevState.count+1}));
    }


    render(){
        return (
            <div>
                <h1>Count EX</h1>
                <p>count: {this.state.count}</p>
                <button onClick={this.increment}>click</button>
                
            </div>
        )
    }

}