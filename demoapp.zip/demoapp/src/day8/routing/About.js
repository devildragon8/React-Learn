import React from 'react'
import NavBarEx from './NavBarEx'

const About = () => {
  return (
    <div>
        <NavBarEx/>
        <h1>About</h1>
    </div>
  )
}

export default About