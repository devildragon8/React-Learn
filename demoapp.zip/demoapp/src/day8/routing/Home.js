import React from 'react'
import NavBarEx from './NavBarEx'

const Home = () => {
  return (
    <div>
        <NavBarEx/>
        <h1>Home</h1>
    </div>
  )
}
export default Home