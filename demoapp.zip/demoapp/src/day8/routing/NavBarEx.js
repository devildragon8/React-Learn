import React from 'react';
import {Link} from 'react-router-dom';

// useNavigate is aslo an inbuilt method which can import from react-router-dom and assign it to an variable and call
// the component just like navigate('/componentname'), before const navigate = useNavigate();

const NavBarEx = () => {
  return (
    <div>
    <nav>
        <ul>
            <li>
                <Link to="/">Home</Link> 
            </li>
            <li>
                <Link to="/about">About</Link>
            </li>
            <li>
                <Link to="/contact">Contact</Link>
            </li>
        </ul>
    </nav>
</div>
  )
}

export default NavBarEx;

