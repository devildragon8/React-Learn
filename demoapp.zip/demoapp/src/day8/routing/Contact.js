import React from 'react'
import NavBarEx from './NavBarEx'
const Contact = () => {
  return (
    <div>
        <NavBarEx/>
        <h1>Contact</h1>
    </div>
  )
}

export default Contact