/* shortcuts
rcc = classcomponent
rfc = functional component
rce = class with export
rfce = function with export
rafc = for arrow function
rcons = constructor
rpce = pure class component
PureComponent will set the update lifecycle as false untill unless state or props is changed, it will render once even if many times called!

*/

import React, { PureComponent } from 'react'

export class Cmpdemo extends PureComponent {
  render() {
    return (
      <div>Cmpdemo</div>
    )
  }
}

export default Cmpdemo;

import React from 'react'

export  function shortcuts() {
  return (
    <div>shortcuts</div>
  )
}

