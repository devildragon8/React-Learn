import React, { Component } from 'react'
import { UserConsumer } from './UserContext'

//calling it with context api is aslo called state lifting with provider and consumer with nested components with same parent!

export class CompF extends Component {
  render() {
    return (

      <UserConsumer>
        {
            (username)=>{
                return <h1>Its time for {username}</h1>
            }
        }
      </UserConsumer>

    )
  }
}

export default CompF;