import React, { Component } from 'react'
import CompF from './CompF'

export class CompE extends Component {
  render() {
    return (
      <div><CompF></CompF></div>
    )
  }
}

export default CompE