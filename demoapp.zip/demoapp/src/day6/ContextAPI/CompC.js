import React, { Component } from 'react'
import CompE from './CompE'

export class CompC extends Component {
  render() {
    return (
      <div><CompE></CompE></div>
    )
  }
}

export default CompC