import React from 'react';

export default function Column() {
  return (
        <div>
            <td>Rahul</td>
            <td>CTS</td>
        </div>
  )
}
