import React from 'react';
import Column from './column';
import Fragement from '../fragement';

export default function Table() {
  return (
    <table>
        <tbody>
            <tr>
                <Column/>
                <Fragement/>
            </tr>
        </tbody>
    </table>
  )
}

