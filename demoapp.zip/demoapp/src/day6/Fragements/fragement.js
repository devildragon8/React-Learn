import React from 'react';

export default function Fragement() {
  return (
    <React.Fragment>
            <td>Rahul</td>
            <td>CTS</td>
    </React.Fragment>
  )
}
