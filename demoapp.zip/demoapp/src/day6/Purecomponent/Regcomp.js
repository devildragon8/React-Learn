import React, { Component } from 'react'

export default class Regcomp extends Component {

 
  }
  render() {
    console.log("**Rendered Regular Component")
    return (
      <div>Purecomp {this.props.name}</div>
    )
  }
}
