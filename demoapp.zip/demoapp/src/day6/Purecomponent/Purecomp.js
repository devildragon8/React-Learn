import React, { PureComponent } from 'react'

export class Purecomp extends PureComponent {
  render() {
    console.log("**Rendered Pure Component")
    return (
      <div>Purecomp {this.props.name}</div>
    )
  }
}

export default Purecomp