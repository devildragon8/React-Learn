import React from "react";

export  function Test (props) {
    return(
      <div>
        <h1>Am from Test Component {props.msg}</h1>
        <div>
            {props.children}
        </div>
      </div>
    );
  }
  
  export class Welcome extends React.Component{
    
    constructor(props){
      super(props)
      this.state={
          data:"Name",
          emps:[
          {id:1,name:'A',salary:1},
          {id:2,name:'B',salary:2},
          {id:3,name:'C',salary:3},
          {id:4,name:'D',salary:4}
          ],
          ID:'',
          Name:'',
          Salary:'',
          Department:'',
          submittedData:[
              {ID:1,Name:"rahul",Salary:20000,Department:"cs"},
          ],
      }
  };


    handleclick = () => {
      this.setState({data:"Rahul"});

    }
    render(props)
    {
      return(
        <div>
          <p>Am from Welcome Component {this.props.name}</p>
          <button onClick={this.handleclick}>click</button>
          <p>{this.state.data}</p>
        </div>
      );
    }
}
