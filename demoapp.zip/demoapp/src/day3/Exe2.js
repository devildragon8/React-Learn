import React from "react";
import '../day1/style.css';


class Exe2 extends React.Component
{
    constructor(props){
        super(props)
        this.state={
            Id: '',
            Name: '',
            Cost: '',
            radioOption:'',
            SelectedValue:'',
            PrintChecked:[],
            submittedData:[]
        }
    };

    handleCheckboxChange = (event) => {
        const { value, checked } = event.target;
        this.setState(prevState => {
          if (checked) {
            return {
                PrintChecked: [...prevState.PrintChecked,value,',']
            };
          } else {
            return {
                PrintChecked: prevState.PrintChecked.filter(item => item !== value)
            };
          }
        });
      }

    handlechange = (e) => {
        this.setState({[e.target.name]:e.target.value});
    }

    formsubmit = (e) => {
        e.preventDefault();
        const { Id, Name, Cost, radioOption, SelectedValue, PrintChecked } = this.state;
        this.setState((prevState) => ({
            submittedData: [...prevState.submittedData, { Id, Name, Cost, radioOption, SelectedValue,  PrintChecked}],
            Id: '',
            Name: '',
            Cost: '',
            radioOption:'',
            SelectedValue:'',
            PrintChecked:[]
        }));
    };

    
    render(){
        const { Id, Name, Cost, submittedData, SelectedValue } = this.state;
        return (
        <div className="first">
            <div>
                    <form onSubmit={this.formsubmit} >
                        <div className="container">
                            <legend style={{color:"green"}} className="ht">Solution 3</legend>
                            <div className="cg">
                                <tr>
                                    <td>
                                        <label class="form-label int item">Product ID</label>
                                    </td>
                                    <td>
                                        <input class="form-control bh" type="number" name="Id"  value={Id}  onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label int item">Product Name</label>
                                    </td>
                                    <td>
                                        <input class="form-control bh" type="text" name="Name" value={Name} onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label int item">Product Cost</label>
                                    </td>
                                    <td>
                                        <input class="form-control bh" type="number" name="Cost" value={Cost} onChange={this.handlechange}  /><br/>
                                    </td>
                                </tr>
                            </div>
                            <div className="gb">
                                <tr>
                                    <td>
                                        <label class="form-label int item">Product Online</label>
                                    </td>
                                    <td>
                                        <label class="form-label int">
                                        <input type="radio" name="radioOption" value="Yes" onChange={this.handlechange}/>
                                        Yes</label>
                                        <label class="form-label int">
                                        <input type="radio" name="radioOption" value="No" onChange={this.handlechange}/>
                                        No</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>    
                                        <label class="form-label int item">Product Category</label>
                                    </td>
                                    <td>
                                        <select name="SelectedValue" value={SelectedValue} onChange={this.handlechange}>
                                            <option value="">Select</option>
                                            <option value="Grocery">Grocery</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Electronics">Electronics</option> 
                                            <option value="Cloths">Cloths</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="form-label int item">Available in store</label>
                                    </td>
                                    <td>
                                        <label class="form-label int">
                                        <input type="checkbox" name="BigBazar" value="BigBazar" onChange={this.handleCheckboxChange}  />
                                        BigBazar</label>
                                        <label class="form-label int">
                                        <input type="checkbox" name="Dmart" value="Dmart"  onChange={this.handleCheckboxChange}  />
                                        Dmart</label>
                                        <label class="form-label int">
                                        <input type="checkbox" name="Reliance" value="Reliance" onChange={this.handleCheckboxChange} />
                                        Reliance</label>
                                        <label class="form-label int">
                                        <input type="checkbox" name="MegaStore" value="MegaStore" onChange={this.handleCheckboxChange} />
                                        MegaStore</label>
                                    </td>
                                     </tr>
                            </div>
                            <div>
                                <tr>
                                    <td>
                                        <br></br>
                                        <br></br>
                                        <button type="submit" class="btn btn-outline-success btn-sm int">Submit All</button>
                                    </td>
                                    <td>
                                        <input type="reset" value="clear"/> 
                                    </td>
                                 </tr>
                            </div>
                        </div>
                    </form>
                     <table className="table table table-hover table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Cost</th>
                                <th>Online</th>
                                <th>Category</th>
                                <th>Store</th>
                            </tr>
                        </thead>
                        <tbody>
                            {submittedData.map((row,index) => { return (
                                <tr key={index}>
                                    <td>{row.Id}</td>
                                    <td>{row.Name}</td>
                                    <td>{row.Cost}</td>
                                    <td>{row.radioOption}</td>
                                    <td>{row.SelectedValue}</td>
                                    <td>{row.PrintChecked}</td>
                                </tr>
                            );})}
                        </tbody>
                    </table>
                </div>
        </div>
        ); } 
}
export default Exe2;