import './App.css';
import React from "react";
// import Exe1 from './day1/Exe1';
// import Exe1Fun from './day5/Exe1Fun';
// import Exe2 from './day3/Exe2';
// import Exe2Fun from './day5/Exe2Fun';
// import Parentcomp from './day6/Purecomponent/Parentcomp';
// import Table from './day6/table';
// import ClickCounter from './day6/HigherOrderComponent/ClickCounter';
// import HoverCounter from './day6/HigherOrderComponent/HoverCounter';
// import CompC from './day6/ContextAPI/CompC';
// import { UserProvider } from './day6/ContextAPI/UserContext';
// import PropType from './day7/PropType';
// import Refs from './day7/Refs';
// import { Fetch } from './day7/curd/Fetch';
// import Insert from './day7/curd/Insert';
// import Update from './day7/curd/Update';
// import Delete from './day7/curd/Delete';
// import Instance from './day7/curd/Instance';
import { Routes, Route } from 'react-router-dom';
// import Home from './day8/routing/Home';
// import About from './day8/routing/About';
// import Contact from './day8/routing/Contact';
// import UseForm from './day9/UseForm';

import LoginForm from './CaseStudy/LoginForm';
import SignupPage from './CaseStudy/SignupPage';
import ProductList from './CaseStudy/ProductList';
import PlaceOrder from './CaseStudy/PlaceOrder';
import ConfirmOrder from './CaseStudy/ConfirmOrder';
import Bill from './CaseStudy/Bill';


export default function App() {
  return (
    <div className="App">
      {/* <p>Welcome to Demo APP</p> */}
      {/* <Exe1></Exe1> */}
      {/* <Exe1Fun></Exe1Fun> */}
      {/* <Exe2></Exe2> */}
      {/* <Exe2Fun></Exe2Fun> */}
      {/* <Parentcomp></Parentcomp> */}
      {/* <Table></Table> */}
      {/* <ClickCounter></ClickCounter>
      <HoverCounter></HoverCounter> */}
      {/* <UserProvider value="LunchBreak">
        <CompC/>
      </UserProvider> */}
      {/* <PropType></PropType> */}
      {/* <Refs></Refs> */}
      {/* <Fetch/> */}
      {/* <Insert></Insert> */}
      {/* <Update></Update> */}
      {/* <Delete></Delete> */}
      {/* <Instance/> */}
      {/* <Home/> */}
      {/* <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
      </Routes> */}
      {/* <UseForm></UseForm> */}

      <Routes>
        <Route path="/" element={<LoginForm/>}/>
        <Route path="/signUpPage" element={<SignupPage/>}/>
        <Route path="/ProductList" element={<ProductList/>}/>
        <Route path="/PlaceOrder" element={<PlaceOrder/>}/>
        <Route path="/ConfirmOrder" element={<ConfirmOrder/>}/>
        <Route path="/Bill" element={<Bill/>}/>
      </Routes>
    </div>
  );
}