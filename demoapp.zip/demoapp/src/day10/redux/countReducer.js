import  reduxConstants from './reduxConstants';
//specify's how the apps state changes in reponse to actions sent to store...
//actions  desc what happened but reducers desc what are the state changes..
//its fun that accepts state and action as args and return next state of app
//(prevState,action)=>newstate
const initialState={count:0};

export default function countReducer(state=initialState,action){

      switch(action.type){

        case reduxConstants.increment :{    
           const newState={count:action.count};
           return newState;
        }

        case reduxConstants.decrement : {
          const newState={count:action.count};
            return newState;

        }

        case reduxConstants.reset: {
            const newState={count:action.count};
            return newState;
        }

        default : {
            return state;
        }

   }

}