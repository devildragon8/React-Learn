import { useDispatch, useSelector } from "react-redux";
import { decrement } from "../redux/countActions";

const DecrementCount = () => {
  //useSelector is a function that takes the current state as an argument
  //and returns whatever data you want from it.

  const response = useSelector((state) => {
    const result = { count: state.count };
    return result;
  });

  //The useDispatch() hook returns a reference to the dispatch function from
  //the Redux store
  const dispatch = useDispatch();

  //Calling preventDefault() during any stage of event flow cancels the event,
  // meaning that any default action normally taken by the implementation as a result of the event will not occur.

  const clickHandler = (event) => {
    event.preventDefault();
    dispatch(decrement());
  };

  return (
    <div>
      <h1>Decrement Count component </h1>
      Count is {response.count}
      <br />
      <button onClick={clickHandler}>Decrement</button>
    </div>
  );
};
export default DecrementCount;
