import React, { Component } from 'react'

export class Refs extends Component {
    constructor(props) {
      super(props)
      this.inputRef = React.createRef()
      this.input = React.createRef()
    }

    componentDidMount(){
        this.input.current.focus()//this will focus the input element and will go to the particular feild here input will auto focused!
        console.log(this.inputRef)
    }

    clickhandle = () => {
        alert(this.inputRef.current.value)
    }
  render() {
    return (
      <div>
        <input type="text" ref={this.inputRef}></input>
        <input type="text" ref={this.input}></input>
        <button onClick={this.clickhandle}>click</button>
      </div>
    )
  }
}

export default Refs