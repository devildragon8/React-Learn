import React from 'react';
import axios from 'axios';
//npm install -g json-server@0.17.3
//json-server --watch data.json --port 8000
//Above keys are to access the particular json file inside the folder and get accessed from the url!

const Insert = () => {
  const post = () => {
      axios.post("http://localhost:8000/users",{
        id:120,
        name:"rahul",
        email:"rahul@gmail.com"
    })
    .then((response)=>{
        console.log("data posted..."+response.data) //here data represents whatever value is there, one or many!
    })
  }
  if(!post) return null
  return (
    <div>
      <h1>hello</h1>
      <button onClick={post}>click</button>
    </div>
  )
}
export default Insert;
