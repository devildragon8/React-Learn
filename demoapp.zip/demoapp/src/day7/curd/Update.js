import React from 'react';
import axios from 'axios';

const Update = () => {
  const put = () => {
      axios.put("http://localhost:8000/users/224",{
        id:224,
        name:"vishal",
        email:"vishal@gmail.com"
    })
    .then((response)=>{
        console.log("data posted..."+response.data)
    })
  }
  return (
    <div>
      <h1>hello</h1>
      <button onClick={put}>click</button>
    </div>
  )
}
export default Update;
