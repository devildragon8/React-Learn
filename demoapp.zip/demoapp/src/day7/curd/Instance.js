import React from 'react';
import axios from 'axios';

const client = axios.create({
    baseURL: "http://localhost:8000/users"
})

export default function Instance() {
    const [post,setPost] = React.useState(null);
    const [error,setError] = React.useState(null);
    React.useEffect(() => {
        client.get('/abcd').then((response) => { // giving valid id will return or gives error
            setPost(response.data)
        }).catch(error => {   //invalid url will get trigerred 404 error
            setError(error);
        });
    },[]);
    
    function deletepost(){
        client
        .delete("/225")
        .then(()=>{
            alert("Post deleted!");
        });
    }
    if(error) return `Error: ${error.message}`; //this should be first to get the return act onces and first to show message!
    if(!post) return "no post!";
    
    
    
  return (
    <div>
        <h1>{post.id}</h1>
        <h1>{post.name}</h1>
        <h1>{post.email}</h1>
        <button onClick={deletepost}>delete post</button>
    </div>
  )
}
