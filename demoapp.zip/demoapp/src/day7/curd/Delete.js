import React from 'react';
import axios from 'axios';

const Update = () => {
  const put = () => {
      axios.delete("http://localhost:8000/users/224")
    .then(()=>{
        console.log("data Deleted...");
    })
  }
  return (
    <div>
      <h1>hello</h1>
      <button onClick={put}>click</button>
    </div>
  )
}
export default Update;
