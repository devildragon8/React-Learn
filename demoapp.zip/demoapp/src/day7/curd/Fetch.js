import axios from "axios";
import React from 'react'
//while starting the json file interior use the run local command first in insert "json-server --watch data.json --port 8000"

const baseurl = "http://localhost:8000/users/222";

export const Fetch = () => {
    const[post,setPost] = React.useState(null);
    React.useEffect(() => {    //use effect is to call outside api's
        axios.get(baseurl).then((response) => {
            setPost(response.data);   // here the data is predefined must use data only
        });
    },[]);

    if(!post) return null

  return (
    <div>
        <h1>{post.id}</h1>
        <h1>{post.name}</h1>
        <h1>{post.email}</h1>
    </div>
  )
}
