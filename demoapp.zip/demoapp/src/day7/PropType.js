import React from 'react'
import PropTypes from 'prop-types'

export const PropType = (props) => {
  return (
    <React.Fragment>
        <div>
            <table align="center" border="2">
                <tr>
                    <th>Type</th>
                    <th>Value</th>
                    <th>Valid</th>
                </tr>
                <tr>
                    <td>Array</td>
                    <td>{props.propArray}</td>
                    <td>{props.propArray ? "true" : "false"}</td>
                </tr>
                <tr>
                    <td>Bool</td>
                    <td>{props.propBool ? "true" : "false"}</td>
                    <td>{props.propBool ? "true" : "false"}</td>
                </tr>
                <tr>
                    <td>Number</td>
                    <td>{props.propNumber}</td>
                    <td>{props.propNumber ? "true" : "false"}</td>
                </tr>
                <tr>
                    <td>string</td>
                    <td>{props.string}</td>
                    <td>{props.string ? "true" : "false"}</td>
                </tr>
                <tr>
                    <td>function</td>
                    <td>{props.function(0)}</td>
                    <td>{props.function(0) ? "true" : "false"}</td>
                </tr>
            </table>
        </div>
    </React.Fragment>
  )
}

PropType.defaultProps = {
    propArray: [1,2,3,4,5],
    propBool: true,
    propNumber:123,
    string: "abc",
    function:function(x){return x+5}

}
PropType.propTypes = {
    propArray: PropTypes.array.isRequired, //PropTypes is default
    propBool: PropTypes.bool.isRequired,
    propNumber: PropTypes.number,
    string: PropTypes.string,
    function: PropTypes.func
}

export default PropType;
