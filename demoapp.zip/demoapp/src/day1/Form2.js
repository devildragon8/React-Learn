import React from "react";
import './Form2.css'

const Form2 = (props) => {
    return(
        <div className="child">
            <p>{props.Id}</p>
            <p>{props.name}</p>
            <p>{props.salary}</p>
            <p>{props.department}     {props.submittedData}</p>
        </div>
    );
}
export default Form2;