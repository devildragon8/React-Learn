import React from "react";
import './style.css';
// import Cmp2 from './cmp2.js';
// import Emp from './emp.js';
// import Form2 from './Form2.js';

class Exe1 extends React.Component
{
    constructor(props){
        super(props)
        this.state={
            data:"",
            emps:[
            {id:1,name:'A',salary:1},
            {id:2,name:'B',salary:2},
            {id:3,name:'C',salary:3},
            {id:4,name:'D',salary:4}
            ],
            ID:'',
            Name:'',
            Salary:'',
            Department:'',
            submittedData:[
                {ID:1,Name:"rahul",Salary:20000,Department:"cs"},
                {ID:2,Name:"chandru",Salary:30000,Department:"it"}
            ],
            editing: false,
            currId: '',
        }
    };

    changeState = () => {
        this.setState({data:"From Cmp2"});
    }

    handlechange = (e) => {
        this.setState({[e.target.name]:e.target.value});
    }

    formsubmit = (e) => {
        e.preventDefault();
        const { ID, Name, Salary , Department, submittedData, editing, currId  } = this.state;
        if (editing) {
          const updatedData = submittedData.map((emp) =>
            emp.ID === currId ? { ID, Name, Salary, Department } : emp
          );
          this.setState({
            submittedData: updatedData,
            editing: false,
            currId: '',
          });
        } 
        else {
          this.setState((prevState) => ({
            submittedData: [...prevState.submittedData, { ID, Name, Salary, Department }],
          }));
        }
        this.setState({
            ID: "",
            Name: "",
            Salary: "",
            Department: "",
        });
      };

    handleUpdate = (id) => {
    const empData = this.state.submittedData.find((row) => row.ID === id);
    this.setState({
        ID: empData.ID,
        Name: empData.Name,
        Salary: empData.Salary,
        Department: empData.Department,
        editing: true,
        currId: id,
    });
    };

    handleDelete = (Id) => {
        this.setState((prevState) => ({
         submittedData: prevState.submittedData.filter((row) => row.ID !== Id),
     }));
    }
    
    render(){
         return(
        <div className="parent">
            {/* <Cmp2 data1={this.state.data}></Cmp2>
            <p>ClassComponent</p>
            <button onClick={this.changeState} type="button">Click</button>
            <div class="left">
                <div class="">
                    <table style={{width: "200px", color: "Green", height: "200px" }} border="1">
                        <tbody>
                        { this.state.emps.map((emp) => { return (
                            <Emp key={emp.id}>{emp.name}</Emp>
                        ); }) }
                        </tbody>
                    </table>
                </div>
            </div> */}
        
            <div className="right ">
    
                    <form onSubmit={this.formsubmit} >
                        <fieldset className="border p-4">
                            <legend className="ht">Form</legend>
                            <div className="form">
                            <label className="form-label int" >ID
                            <input className="form-control" type="number" name="ID" value={this.state.ID} onChange={this.handlechange} placeholder="Enter ID" required /><br/>
                            </label>
                            <label className="form-label int">Name
                            <input className="form-control" type="text" name="Name" value={this.state.Name} onChange={this.handlechange} placeholder="Enter Name" required /><br/>
                            </label>
                            <label className="form-label int">Salary
                            <input className="form-control" type="number" name="Salary" value={this.state.Salary} onChange={this.handlechange} placeholder="Enter Salary" required /><br/>
                            </label>
                            <label className="form-label int">Department
                            <input className="form-control" type="text" name="Department" value={this.state.Department} onChange={this.handlechange} placeholder="Enter Department" required /><br/>
                            </label>
                            <button  className="btn btn-primary button" type="submit">Submit All</button>
                            <input type="reset"></input>
                        </div>
                        </fieldset>
                      
                    </form>
                    {/* { this.state.submittedData.map((data) => { return (
                            <Form2 Id={data.ID} name={data.Name} salary={data.Salary} department={data.Department}/>
                        ); }) } */}
                     <table  className="table table table-hover table-bordered table-striped">
                        <thead className="table-dark">
                            <tr className="tr">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Salary</th>
                                <th>Department</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.submittedData.map((row) => { return (
                                <tr className="tr" key={row.ID}>
                                    <td>{row.ID}</td>
                                    <td>{row.Name}</td>
                                    <td>{row.Salary}</td>
                                    <td>{row.Department}</td>
                                    <td>
                                        <button className="btn btn-secondary int" onClick={()=> this.handleUpdate(row.ID)}>Update</button>
                                        <button className="btn btn-danger" onClick={()=> this.handleDelete(row.ID)}>Delete</button>
                                    </td>
                                </tr>
                            );})}
                        </tbody>
                    </table>
                </div>
        </div>
        ); } 
}
export default Exe1;