import React from "react";

const Emp = (props) => {
    return(
        <tr>
            <td>
                {props.children}
            </td>
        </tr>
        
           
       
    );
}

export default Emp;