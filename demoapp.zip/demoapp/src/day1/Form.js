import React from "react";


class Form extends React.Component
{
    constructor(){
        super()
        this.state={}
    }



    render(){
        return(
            <div className="parent">
                
            </div>
        );
    }
}

export default Form;