import React from "react";

const Cmp2 = (props) => {
    return(
        <div className="child">
            <p>Cmp2</p>
            <h1>{props.data1}</h1>
        </div>
    );
}

export default Cmp2;