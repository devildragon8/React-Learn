import React from 'react';
import { useForm } from 'react-hook-form'; 

const UseForm = () => {
    const { register, handleSubmit,formState: {errors}} = useForm();
    const onSubmit = (data) => {
        console.log(data);
    }
  return (
    <div>
        <form onSubmit={handleSubmit(onSubmit)}>
            <label>Email</label>
                <input type="email" {...register("email",{required :true,pattern:/^\S+@\S+$/i})}></input>
                {errors.email && <p>Email is required and must be valid</p>}
              
                <label>Password</label>
                <input type="password" {...register("password",{required :true,minLength:6,maxLength:12})}></input>
                {errors.password && <p>Password is required</p>}
                <button type="submit">submit</button>
        </form>
    </div>
  )
}

export default UseForm