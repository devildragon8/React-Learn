import React from 'react'
// npm i react-hook-form  "this is to automatically handle form validations!"

const FormValidations = () => {
    const[inputValue,setInputValue] = React.useState('');
    const[inputError,setInputError] = React.useState('');

    function handlechange(e){
        const value = e.target.value;
        setInputValue(value);
        if(value.length <5){
            setInputError('Input must be at least 5 charcters');
        } else setInputError(null);
    }

    function handlesubmit(e){
        e.preventDefault();
        if(inputValue.length >=5){
            //it will submit normally
        }else setInputError('Input must be at least 5 charcters');
    }

  return (
    <div>
        <form onSubmit={handlesubmit}>
            <label>
                type:
                <input type="text" value={inputValue} onChange={handlechange}></input>
            </label>
            {inputError && <div style={{colour:red}}>{inputError}</div>}
            <button type="submit">submit</button>
        </form>
    </div>
  )
}

export default FormValidations